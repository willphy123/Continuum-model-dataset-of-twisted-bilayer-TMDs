using LinearAlgebra
using Printf
using DataStructures
using PyPlot
using PyCall
using LaTeXStrings
using FileIO, JLD2

const bohr2ang::Float64 = 0.52917725
const Ryd::Float64      = 13.605693122994
const bohr_mag::Float64 = 9.2740100783e-24
const eV2J::Float64     = 1.602e-19
const weber::Float64    = 2 * 2.067833848e-15
const muB::Float64      = 5.788e-5 * 1000  #(meV)

struct kp_band
	nk::Int64
	nk_dft::Int64
	nbnd_dft::Int64
	kappa_b::Vector{Float64}
	kappa_t::Vector{Float64}
	kp::Vector{Vector{Float64}}
	ks::Vector{Float64}
	band_range::Vector{Float64}
end
struct para_local
	theta::Float64
	meff::Float64
	Eg::Float64
	vF::Float64
	beta::Vector{Float64}
end
struct pot_g_sub
	eps_g_top::Array{ComplexF64, 2}
	eps_g_bot::Array{ComplexF64, 2}
	Vf_g_top::Array{ComplexF64, 2}
	Vf_g_bot::Array{ComplexF64, 2}
	T_g::Array{ComplexF64, 2}
	Tcv_g::Array{ComplexF64, 2}
	Tvc_g::Array{ComplexF64, 2}
	Vp_g_top::Array{ComplexF64, 2}
	Vp_g_bot::Array{ComplexF64, 2}
	Us_g_top::Array{ComplexF64, 2}
	Us_g_bot::Array{ComplexF64, 2}
	A_g_top::Array{ComplexF64, 3}
	A_g_bot::Array{ComplexF64, 3}
	A2_g_top::Array{ComplexF64, 2}
	A2_g_bot::Array{ComplexF64, 2}
end
struct info_gm_sub
	nshell::Int64
	gm_sub::Array{Int64, 3}
	gqm_sub::Array{Int64, 3}
end

function set_kpath(kp_high::Vector{Vector{Float64}}, nksub::Int64, arec::Array{Float64, 2})
	kp = Vector{Vector{Float64}}()
	f=open("kp.dat", "w")
	for ik in 1:(length(kp_high)-1)
		for j in 1:nksub
			kp_tmp = kp_high[ik] + (kp_high[ik+1] - kp_high[ik]) / nksub * (j-1)
			push!(kp, kp_tmp)
			@printf(f, " %24.16f %24.16f %24.16f\n", kp_tmp...)
		end
	end
	push!(kp, kp_high[length(kp_high)])
	@printf(f, " %24.16f %24.16f %24.16f\n", kp_high[length(kp_high)]...)
	close(f)
	nk = length(kp)
	ks = zeros(Float64, nk)
	for ik in 2:nk
		ks[ik] = ks[ik-1] + norm((kp[ik] - kp[ik-1])'*arec)
	end
	return kp, ks, nk
end

function get_gvec!(ecut::Float64, ngcut::Int64, arec::Array{Float64, 2})
	
	m = 0
	for i1 in (-ngcut):ngcut
		for i2 in (-ngcut):ngcut
			if norm([i1, i2, 0]' * arec)^2 < ecut
				m+=1
			end
		end
	end
	ngvec = m
	gvec = zeros(Int64, ngvec, 3)

	m = 1
	for i1 in (-ngcut):ngcut
		for i2 in (-ngcut):ngcut
			if norm([i1, i2, 0]' * arec)^2 < ecut
				gvec[m, :] = [i1, i2, 0]
				m+=1
			end
		end
	end
	return ngvec, gvec
end


function init_band_fourier(input_param::Dict)

    aM = input_param["aM"]/bohr2ang 
	adir = zeros(Float64, 3, 3)
	adir[1, 1] = aM 
	adir[2, 1] = aM/2
	adir[2, 2] = aM * 3^0.5/2
	adir[3, 3] = 20 

	deg = -pi/6
	Rot = zeros(Float64, 3, 3)
	Rot[1, :] = [cos(deg) -sin(deg) 0]  ###conunterclock wise rotation
	Rot[2, :] = [sin(deg) cos(deg) 0]
	Rot[3, 3] = 1.0
	for l in 1:3
		adir[l, :] = Rot * adir[l, :]
	end

    arec = 2pi * inv(adir)'

	kp, ks, nk = set_kpath(input_param["kp_high"], input_param["nksub"], arec)
    
    ngvec, gvec = get_gvec!(input_param["ecut"], input_param["ngcut"], arec)

	kp_band1 = kp_band(nk, input_param["nk_dft"], input_param["nbnd_dft"], input_param["kappa"][1], input_param["kappa"][2], kp, ks, input_param["band_range"])
	theta = input_param["theta"] / 180 * pi
	para_local1 = para_local(theta, input_param["meff"], input_param["Eg"], input_param["vF"], input_param["beta"])

	is_dft = input_param["is_dft"]
	ext_field1 = input_param["D"]/Ryd/1000

	return adir, arec, ngvec, gvec, kp_band1, para_local1, is_dft, ext_field1
end

function read_pot(nshell::Int64)

	gm_sub = zeros(Int64, 12, 3, nshell)
	gqm_sub = zeros(Int, 6, 3, nshell)

	eps_g = zeros(ComplexF64, 12, nshell)
	Vf_g = zeros(ComplexF64, 12, nshell)
	Vp_g_bot = zeros(ComplexF64, 12, nshell)
	Vp_g_top = zeros(ComplexF64, 12, nshell)
	Us_g_bot = zeros(ComplexF64, 12, nshell)
	Us_g_top = zeros(ComplexF64, 12, nshell)
	Bu_g_top = zeros(ComplexF64, 12, nshell)
	Bu_g_bot = zeros(ComplexF64, 12, nshell)
	T_g = zeros(ComplexF64, 6, nshell)
	Tcv_g = zeros(ComplexF64, 6, nshell)
	Tvc_g = zeros(ComplexF64, 6, nshell)
	A_g_bot = zeros(ComplexF64, 12, nshell, 2)
	A_g_top = zeros(ComplexF64, 12, nshell, 2)
	A2_g_bot = zeros(ComplexF64, 12, nshell)
	A2_g_top = zeros(ComplexF64, 12, nshell)

	f=open("eps_g.dat", "r")
	for j in 1:nshell
		tmp = split(readline(f))
		if j == 4 || j == 7 || j==9 || j==10
			for i1 in 1:12
				tmp = split(readline(f))
				eps_g[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
				gm_sub[i1, 1, j] = parse(Int64, tmp[1])
				gm_sub[i1, 2, j] = parse(Int64, tmp[2])
			end
		else
			for i1 in 1:6
				tmp = split(readline(f))
				eps_g[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
				gm_sub[i1, 1, j] = parse(Int64, tmp[1])
				gm_sub[i1, 2, j] = parse(Int64, tmp[2])
			end
		end
	end
	close(f)
	eps_g_bot = eps_g / Ryd / 1000
	eps_g_top = eps_g / Ryd / 1000

	f=open("Vf_g.dat", "r")
	for j in 1:nshell
		tmp = split(readline(f))
		if j == 4 || j == 7 || j==9 || j==10
			for i1 in 1:12
				tmp = split(readline(f))
				Vf_g[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
				gm_sub[i1, 1, j] = parse(Int64, tmp[1])
				gm_sub[i1, 2, j] = parse(Int64, tmp[2])
			end
		else
			for i1 in 1:6
				tmp = split(readline(f))
				Vf_g[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
				gm_sub[i1, 1, j] = parse(Int64, tmp[1])
				gm_sub[i1, 2, j] = parse(Int64, tmp[2])
			end
		end
	end
	close(f)
	Vf_g_bot = -Vf_g/2 / Ryd / 1000
	Vf_g_top = Vf_g/2 / Ryd / 1000

	f=open("Vp_g_bot.dat", "r")
	for j in 1:nshell
		tmp = split(readline(f))
		if j == 4 || j == 7 || j==9 || j==10
			for i1 in 1:12
				tmp = split(readline(f))
				Vp_g_bot[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
				gm_sub[i1, 1, j] = parse(Int64, tmp[1])
				gm_sub[i1, 2, j] = parse(Int64, tmp[2])
			end
		else
			for i1 in 1:6
				tmp = split(readline(f))
				Vp_g_bot[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
				gm_sub[i1, 1, j] = parse(Int64, tmp[1])
				gm_sub[i1, 2, j] = parse(Int64, tmp[2])
			end
		end
	end
	close(f)
	Vp_g_bot = Vp_g_bot / Ryd / 1000

	f=open("Vp_g_top.dat", "r")
	for j in 1:nshell
		tmp = split(readline(f))
		if j == 4 || j == 7 || j==9 || j==10
			for i1 in 1:12
				tmp = split(readline(f))
				Vp_g_top[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
				gm_sub[i1, 1, j] = parse(Int64, tmp[1])
				gm_sub[i1, 2, j] = parse(Int64, tmp[2])
			end
		else
			for i1 in 1:6
				tmp = split(readline(f))
				Vp_g_top[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
				gm_sub[i1, 1, j] = parse(Int64, tmp[1])
				gm_sub[i1, 2, j] = parse(Int64, tmp[2])
			end
		end
	end
	close(f)
	Vp_g_top = Vp_g_top / Ryd / 1000

	f=open("Us_g_bot.dat", "r")
	for j in 1:nshell
		tmp = split(readline(f))
		if j == 4 || j == 7 || j==9 || j==10
			for i1 in 1:12
				tmp = split(readline(f))
				Us_g_bot[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
				gm_sub[i1, 1, j] = parse(Int64, tmp[1])
				gm_sub[i1, 2, j] = parse(Int64, tmp[2])
			end
		else
			for i1 in 1:6
				tmp = split(readline(f))
				Us_g_bot[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
				gm_sub[i1, 1, j] = parse(Int64, tmp[1])
				gm_sub[i1, 2, j] = parse(Int64, tmp[2])
			end
		end
	end
	close(f)
	Us_g_bot = Us_g_bot / Ryd / 1000

	f=open("Us_g_top.dat", "r")
	for j in 1:nshell
		tmp = split(readline(f))
		if j == 4 || j == 7 || j==9 || j==10
			for i1 in 1:12
				tmp = split(readline(f))
				Us_g_top[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
				gm_sub[i1, 1, j] = parse(Int64, tmp[1])
				gm_sub[i1, 2, j] = parse(Int64, tmp[2])
			end
		else
			for i1 in 1:6
				tmp = split(readline(f))
				Us_g_top[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
				gm_sub[i1, 1, j] = parse(Int64, tmp[1])
				gm_sub[i1, 2, j] = parse(Int64, tmp[2])
			end
		end
	end
	close(f)
	Us_g_top = Us_g_top / Ryd / 1000

	f=open("T_g.dat", "r")
	for j in 1:nshell
		tmp = split(readline(f))
		if j == 3 || j==4 || j==6 || j==8 || j==9 || j==10
			for i1 in 1:6
				tmp = split(readline(f))
				T_g[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
				gqm_sub[i1, 1, j] = parse(Int64, tmp[1])
				gqm_sub[i1, 2, j] = parse(Int64, tmp[2])
			end
		else
			for i1 in 1:3
				tmp = split(readline(f))
				T_g[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
				gqm_sub[i1, 1, j] = parse(Int64, tmp[1])
				gqm_sub[i1, 2, j] = parse(Int64, tmp[2])
			end
		end
	end
	close(f)
	T_g = T_g / Ryd / 1000

	f=open("Tcv_g.dat", "r")
	for j in 1:nshell
		tmp = split(readline(f))
		if j == 3 || j==4 || j==6 || j==8 || j==9 || j==10
			for i1 in 1:6
				tmp = split(readline(f))
				Tcv_g[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
			end
		else
			for i1 in 1:3
				tmp = split(readline(f))
				Tcv_g[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
			end
		end
	end
	close(f)
	Tcv_g = Tcv_g / Ryd / 1000

	f=open("Tvc_g.dat", "r")
	for j in 1:nshell
		tmp = split(readline(f))
		if j == 3 || j==4 || j==6 || j==8 || j==9 || j==10
			for i1 in 1:6
				tmp = split(readline(f))
				Tvc_g[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
			end
		else
			for i1 in 1:3
				tmp = split(readline(f))
				Tvc_g[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
			end
		end
	end
	close(f)
	Tvc_g = Tvc_g / Ryd / 1000

	f=open("A_g_top_x.dat", "r")
	for j in 1:nshell
		tmp = split(readline(f))
		if j == 4 || j == 7 || j==9 || j==10
			for i1 in 1:12
				tmp = split(readline(f))
				A_g_top[i1, j, 1] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
			end
		else
			for i1 in 1:6
				tmp = split(readline(f))
				A_g_top[i1, j, 1] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
			end
		end
	end
	close(f)
	f=open("A_g_top_y.dat", "r")
	for j in 1:nshell
		tmp = split(readline(f))
		if j == 4 || j == 7 || j==9 || j==10
			for i1 in 1:12
				tmp = split(readline(f))
				A_g_top[i1, j, 2] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
			end
		else
			for i1 in 1:6
				tmp = split(readline(f))
				A_g_top[i1, j, 2] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
			end
		end
	end
	close(f)

	f=open("A_g_bot_x.dat", "r")
	for j in 1:nshell
		tmp = split(readline(f))
		if j == 4 || j == 7 || j==9 || j==10
			for i1 in 1:12
				tmp = split(readline(f))
				A_g_bot[i1, j, 1] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
			end
		else
			for i1 in 1:6
				tmp = split(readline(f))
				A_g_bot[i1, j, 1] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
			end
		end
	end
	close(f)
	f=open("A_g_bot_y.dat", "r")
	for j in 1:nshell
		tmp = split(readline(f))
		if j == 4 || j == 7 || j==9 || j==10
			for i1 in 1:12
				tmp = split(readline(f))
				A_g_bot[i1, j, 2] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
			end
		else
			for i1 in 1:6
				tmp = split(readline(f))
				A_g_bot[i1, j, 2] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
			end
		end
	end
	close(f)

	f=open("A2_g_top.dat", "r")
	for j in 1:nshell
		tmp = split(readline(f))
		if j == 4 || j == 7 || j==9 || j==10
			for i1 in 1:12
				tmp = split(readline(f))
				A2_g_top[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
			end
		else
			for i1 in 1:6
				tmp = split(readline(f))
				A2_g_top[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
			end
		end
	end
	close(f)
	f=open("A2_g_bot.dat", "r")
	for j in 1:nshell
		tmp = split(readline(f))
		if j == 4 || j == 7 || j==9 || j==10
			for i1 in 1:12
				tmp = split(readline(f))
				A2_g_bot[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
			end
		else
			for i1 in 1:6
				tmp = split(readline(f))
				A2_g_bot[i1, j] = parse(Float64, tmp[3]) + im * parse(Float64, tmp[4])
			end
		end
	end
	close(f)
	pot_g_sub1 = pot_g_sub(eps_g_top, eps_g_bot, Vf_g_top, Vf_g_bot, T_g, Tcv_g, Tvc_g, Vp_g_top, Vp_g_bot, Us_g_top, Us_g_bot, A_g_top, A_g_bot,
		A2_g_top, A2_g_bot)
	return gm_sub, gqm_sub, pot_g_sub1
end

function get_pot_fourier()

	nshell = 10
	gm_sub, gqm_sub, pot_g_sub1 = read_pot(nshell)
	info_gm_sub1 = info_gm_sub(nshell, gm_sub, gqm_sub)

	return info_gm_sub1, pot_g_sub1
end

function get_H0_fourier!(arec::Array{Float64, 2}, para_local1::para_local, ngvec::Int64, gvec::Array{Int64, 2}, info_gm_sub1::info_gm_sub, kappa_b::Vector{Float64}, kappa_t::Vector{Float64},
	pot_g_sub1::pot_g_sub, ext_field1::Float64, kp::Vector, is_K::Bool)

	meff = para_local1.meff
	Eg = para_local1.Eg / Ryd
	vF = para_local1.vF
	beta = para_local1.beta
	gm_sub = info_gm_sub1.gm_sub
	gqm_sub = info_gm_sub1.gqm_sub
	nshell = info_gm_sub1.nshell

	if is_K
		gflag = 1
	else
		gflag = -1
	end
    tau = 1 
	theta = tau * para_local1.theta

	H = zeros(ComplexF64, 2ngvec, 2ngvec)
	gtmp = zeros(Int64, 3)

    q1 = kappa_b - kappa_t
	g1_s = sqrt(sum(arec[1, :] .^ 2))
	q1_s = sqrt(sum(vec(q1' * arec) .^ 2))

	for ig1 in 1:ngvec
		H[ig1, ig1] += - ext_field1 / 2
		for ig2 in 1:ngvec
			gtmp[:] = gflag*(gvec[ig1, :] - gvec[ig2, :])
			for j in 1:nshell
				if j == 4 || j == 7 || j==9 || j==10
					ngm = 12
				else
					ngm = 6
				end
				for igm in 1:ngm
					if gtmp[1] == gm_sub[igm, 1, j] && gtmp[2] == gm_sub[igm, 2, j]
						H[ig1, ig2] +=
							(pot_g_sub1.eps_g_bot[igm, j] + pot_g_sub1.Vf_g_bot[igm, j] + pot_g_sub1.Vp_g_bot[igm, j] + pot_g_sub1.Us_g_bot[igm, j])
					end
				end
					for igm in 1:ngm
						if gtmp[1] == gm_sub[igm, 1, j] && gtmp[2] == gm_sub[igm, 2, j]
							ktmp = (kp+gflag * gvec[ig2, :] - kappa_b)'*arec
							ktmp2 = (kp+gflag * gvec[ig1, :] - kappa_b)'*arec
							H[ig1, ig2] += -2 * sqrt(2) / meff * (ktmp[1] * pot_g_sub1.A_g_bot[igm, j, 1] + ktmp[2] * pot_g_sub1.A_g_bot[igm, j, 2])
							H[ig1, ig2] += -2 / meff * pot_g_sub1.A2_g_bot[igm, j]
						end
					end
			end
		end
	end
	for ig1 in (ngvec+1):(2*ngvec)
		H[ig1, ig1] += ext_field1 / 2
		for ig2 in (ngvec+1):(2*ngvec)
			gtmp[:] = gflag*(gvec[ig1-ngvec, :] - gvec[ig2-ngvec, :])
			for j in 1:nshell
				if j == 4 || j == 7 || j==9 || j==10
					ngm = 12
				else
					ngm = 6
				end
				for igm in 1:ngm
					if gtmp[1] == gm_sub[igm, 1, j] && gtmp[2] == gm_sub[igm, 2, j]
						H[ig1, ig2] +=
							(pot_g_sub1.eps_g_top[igm, j] + pot_g_sub1.Vf_g_top[igm, j] + pot_g_sub1.Vp_g_top[igm, j] + pot_g_sub1.Us_g_top[igm, j])
					end
				end
					for igm in 1:ngm
						if gtmp[1] == gm_sub[igm, 1, j] && gtmp[2] == gm_sub[igm, 2, j]
							ktmp = (kp + gflag * gvec[ig2-ngvec, :] - kappa_t)'*arec
							ktmp2 = (kp+gflag * gvec[ig1-ngvec, :] - kappa_t)'*arec
							H[ig1, ig2] += -2 * sqrt(2) / meff * (ktmp[1] * pot_g_sub1.A_g_top[igm, j, 1] + ktmp[2] * pot_g_sub1.A_g_top[igm, j, 2])
							H[ig1, ig2] += -2 / meff * pot_g_sub1.A2_g_top[igm, j]
						end
					end
			end
		end
	end

	for ig1 in 1:ngvec
		for ig2 in (ngvec+1):2ngvec
			gtmp[:] = gflag*(gvec[ig1, :] - gvec[ig2-ngvec, :])
			vtmp1 = (kp+gflag*gvec[ig1, :]-kappa_b)' * arec
			vtmp2 = (kp+gflag*gvec[ig2-ngvec, :]-kappa_t)' * arec
			for j in 1:nshell
				if j == 3 || j==4 || j==6 || j==8 || j==9 || j==10
					ngm = 6
				else
					ngm = 3
				end
				for igm in 1:ngm
					if gtmp[1] == gqm_sub[igm, 1, j] && gtmp[2] == gqm_sub[igm, 2, j]
						H[ig1, ig2] +=
							pot_g_sub1.T_g[igm, j] - vF * (tau * vtmp1[1] + im * vtmp1[2]) * exp(im * theta/2) / Eg * pot_g_sub1.Tcv_g[igm, j] -
							vF * (tau * vtmp2[1] - im * vtmp2[2]) * exp(im * theta/2) / Eg * pot_g_sub1.Tvc_g[igm, j]
					end
				end
			end

		end
	end
	H[(ngvec+1):2ngvec, 1:ngvec] = H[1:ngvec, (ngvec+1):2ngvec]'  ## ' is transpoe + conjugate 
	return H
end

function get_H_kin!(arec::Array{Float64, 2}, para_local1::para_local, ngvec::Int64, gvec::Array{Int64, 2}, kappa_b::Vector{Float64}, kappa_t::Vector{Float64}, kp::Vector{Float64}, is_K::Bool)

	meff = para_local1.meff
	beta = para_local1.beta
	if is_K
		gflag = 1
	else
		gflag = -1
	end
	tau = 1
	H = zeros(ComplexF64, 2ngvec, 2ngvec)
	gtmp = zeros(Int64, 3)

	deg = para_local1.theta/2
	Rot = zeros(Float64, 3, 3)
	Rot[1, :] = [cos(deg) -sin(deg) 0]  
	Rot[2, :] = [sin(deg) cos(deg) 0]
	Rot[3, 3] = 1.0

	deg = -para_local1.theta/2
	Rot_inv = zeros(Float64, 3, 3)
	Rot_inv[1, :] = [cos(deg) -sin(deg) 0]  
	Rot_inv[2, :] = [sin(deg) cos(deg) 0]
	Rot_inv[3, 3] = 1.0


	for ig1 in 1:ngvec
		vtmp = (kp+gflag*gvec[ig1, :] - kappa_b)' * arec
		vtmp = Rot_inv * vtmp'
		H[ig1, ig1] +=
			-1.0 / meff * norm(vtmp) ^ 2 +
			beta[1] * ((tau * vtmp[1] + im * vtmp[2])^3 + (tau * vtmp[1] - im * vtmp[2])^3) +
			beta[2] * norm(vtmp)^4 +
			beta[3] * ((tau * vtmp[1] + im * vtmp[2])^3 + (tau * vtmp[1] - im * vtmp[2])^3) * norm(vtmp)^2 +
			beta[4] * norm(vtmp)^6
	end

	for ig1 in (ngvec+1):(2*ngvec)
		vtmp = (kp+gflag*gvec[ig1-ngvec, :]-kappa_t)'*arec
		vtmp = Rot * vtmp'
		H[ig1, ig1] +=
			-1.0 / meff * norm(vtmp) ^ 2 +
			beta[1] * ((tau * vtmp[1] + im * vtmp[2])^3 + (tau * vtmp[1] - im * vtmp[2])^3) +
			beta[2] * norm(vtmp)^4 +
			beta[3] * ((tau * vtmp[1] + im * vtmp[2])^3 + (tau * vtmp[1] - im * vtmp[2])^3) * norm(vtmp)^2 +
			beta[4] * norm(vtmp)^6
	end
	return H
end

function diag_H!(H::AbstractMatrix{ComplexF64}, ngvec::Int64)
	enk_orig = real(eigvals(Hermitian(H)))
	evec_orig = eigvecs(Hermitian(H))
	enk = zeros(Float64, 2ngvec)
	evec = zeros(ComplexF64, 2ngvec, 2ngvec)
	sort_id = sortperm(enk_orig; rev = true)
	enk[sort_id[:]] = enk_orig[:] * Ryd
	evec[:, sort_id[:]] = evec_orig[:, :]
	return enk, evec
end

function calc_H_fourier!(arec::Array{Float64, 2}, kp_band1::kp_band, para_local1::para_local, is_dft::Bool, ngvec::Int64, gvec::Array{Int64, 2}, info_gm_sub1::info_gm_sub, pot_g_sub1::pot_g_sub,
	ext_field1::Float64,  flog::IO)

	nk = kp_band1.nk
	kp = kp_band1.kp
    en_K = zeros(Float64, 2ngvec, nk)
	en_Kp = zeros(Float64, 2ngvec, nk)
	evec_K = zeros(ComplexF64, 2ngvec, 2ngvec, nk)
	evec_Kp = zeros(ComplexF64, 2ngvec, 2ngvec, nk)
	
	is_K = true
	for ik in 1:nk
		print(flog, "ik:", ik, "\n")
		flush(flog)
		t1 = @elapsed H0 = get_H0_fourier!(arec, para_local1, ngvec, gvec, info_gm_sub1, kp_band1.kappa_b, kp_band1.kappa_t, pot_g_sub1, ext_field1, kp[ik], is_K)
		print(flog, "Elapsed time: ", t1, " seconds\n")
		flush(flog)
		t1 = @elapsed H_kin = get_H_kin!(arec, para_local1, ngvec, gvec, kp_band1.kappa_b, kp_band1.kappa_t, kp[ik], is_K)
		print(flog, "Elapsed time: ", t1, " seconds\n")
		flush(flog)
		H = H0 + H_kin
		t1 = @elapsed en_K[:, ik], evec_K[:, :, ik] = diag_H!(H, ngvec)
		print(flog, "Elapsed time: ", t1, " seconds\n")
		flush(flog)
	end

	is_K = false
	for ik in 1:nk
		print(flog, "ik:", ik, "\n")
		flush(flog)
		t1 = @elapsed H0 = get_H0_fourier!(arec, para_local1, ngvec, gvec, info_gm_sub1, kp_band1.kappa_b, kp_band1.kappa_t, pot_g_sub1, ext_field1, -kp[ik], is_K)
		print(flog, "Elapsed time: ", t1, " seconds\n")
		flush(flog)
		t1 = @elapsed H_kin = get_H_kin!(arec, para_local1, ngvec, gvec, kp_band1.kappa_b, kp_band1.kappa_t, -kp[ik], is_K)
		print(flog, "Elapsed time: ", t1, " seconds\n")
		flush(flog)
		H = conj(H0 + H_kin)
		t1 = @elapsed en_Kp[:, ik], evec_Kp[:, :, ik] = diag_H!(H, ngvec)
		print(flog, "Elapsed time: ", t1, " seconds\n")
		flush(flog)
	end
	return en_K, evec_K, en_Kp, evec_Kp
end


function plot_band!(kp_band1::kp_band, is_dft::Bool, ngvec::Int64, en_K::Array{Float64, 2}, en_Kp::Array{Float64, 2}, sflag::String)

	np=pyimport("numpy")
	matplot=pyimport("matplotlib")
	ticker = pyimport("matplotlib.ticker")
	scp = pyimport("scipy")
	scp_int = pyimport("scipy.interpolate")
	nk = kp_band1.nk
	ks = kp_band1.ks / bohr2ang
	nk_dft = kp_band1.nk_dft
	nbnd_dft = kp_band1.nbnd_dft
	band_range=kp_band1.band_range

	matplotlib.rc("font", family = "STIXGeneral")

	if is_dft
		ks_dft = zeros(Float64, nk_dft)
		en_dft = zeros(Float64, nbnd_dft, nk_dft)
		f=open("Es-band.dat", "r")
		for ibnd in 1:nbnd_dft
			for ik in 1:nk_dft
				tmp = split(readline(f))
				if ibnd==1
					ks_dft[ik] = parse(Float64, tmp[1])
				end
				en_dft[ibnd, ik] = parse(Float64, tmp[2])
			end
			readline(f)
		end
		close(f)
	end

	fig, ax1 = plt.subplots()
	for axis in ["top", "bottom", "left", "right"]
		ax1.spines[axis].set_linewidth(2)
		ax1.tick_params(width = 1.5, direction = "in", length = 8, pad = 8)
	end

	nfont = 28
	ax1.tick_params(axis = "x", which = "minor", direction = "in", length = 4, labelsize = nfont)
	fig.set_size_inches(9, 6.75)
	ax1.xaxis.major.formatter._useMathText = true
	plt.rcParams["mathtext.fontset"] = "stix"
		
    Ef_K = maximum(en_K[1:2ngvec, :])
    Ef_Kp = maximum(en_Kp[1:2ngvec, :])
	Ef = maximum([Ef_K, Ef_Kp])
	en_K .-= Ef
	en_Kp .-= Ef

	for ib in 1:2ngvec
		if ib==1
			plot(ks, en_K[ib, :] * 1000, "r-", linewidth = 1.5, label = "Model:K")
			plot(ks, en_Kp[ib, :] * 1000, "b-", linewidth = 1.5, label = "Model:K'")
		else
			plot(ks, en_K[ib, :] * 1000, "r-", linewidth = 1.5)
			plot(ks, en_Kp[ib, :] * 1000, "b-", linewidth = 1.5)
		end
	end
	if is_dft
		for ib in 1:nbnd_dft
			if ib==1
				scatter(ks_dft, en_dft[ib, :] * 1000, marker = "o", color = "grey", s = 5, label = "DFT")
			else
				scatter(ks_dft, en_dft[ib, :] * 1000, marker = "o", color = "grey", s = 5)
			end
		end
	end

	kx = ks

	f=open("Es-band-model-K.dat", "w")
	for ib in 1:2ngvec
		for ik in 1:nk
			@printf(f, "%20.16e %20.16e\n", ks[ik], en_K[ib, ik])
		end
		@printf(f, "\n")
	end
	close(f)
	f=open("Es-band-model-Kp.dat", "w")
	for ib in 1:2ngvec
		for ik in 1:nk
			@printf(f, "%20.16e %20.16e\n", ks[ik], en_Kp[ib, ik])
		end
		@printf(f, "\n")
	end
	close(f)

	plt.xticks([])
	#xlim([-0.2, 1])
	ylim(band_range * 1000)
	#ylim([-100, 5])
	plt.legend(loc = "lower right", fontsize = 25)
	#plt.xlim(0, kx[61])
	#plt.text(0.0, -105, "-m",horizontalalignment="center",  fontsize=nfont, fontname="STIXGeneral")
	#plt.text(kx[11], -105, "γ",horizontalalignment="center",  fontsize=nfont, fontname="STIXGeneral")
	#plt.text(kx[21] , -105, "m",horizontalalignment="center",  fontsize=nfont, fontname="STIXGeneral")
	#plt.text(kx[31], -105, "kappa",horizontalalignment="center",  fontsize=nfont, fontname="STIXGeneral")
	#plt.text(kx[41], -105, "γ",horizontalalignment="center",  fontsize=nfont, fontname="STIXGeneral")
	plt.axvline(x=kx[21], color="k", alpha=0.3, linestyle="-", linewidth=1.0)
	plt.axvline(x=kx[41], color="k", alpha=0.3, linestyle="-", linewidth=1.0)
	ax1.set_ylabel("Energy (meV)", fontsize = nfont+2, fontname = "STIXGeneral")

	for axis in ["top", "bottom", "left", "right"]
		ax1.spines[axis].set_linewidth(1.5)
	end
	ax1.tick_params(width = 1.5)
	plt.yticks(fontsize = nfont, fontname = "STIXGeneral")
	plt.xticks(fontsize = nfont, fontname = "STIXGeneral") # fontname='Arial')
	fig.tight_layout()
	savefig("plot-model-band-$sflag.png", dpi = 300)
	close(fig)
end


function get_band_fourier(input_param::Dict)

	flog = open("log", "w")

	adir, arec, ngvec, gvec, kp_band1, para_local1, is_dft, ext_field1=init_band_fourier(input_param)
	print(flog, "init done\n")
	flush(flog)

	info_gm_sub1, pot_g_sub1 = get_pot_fourier()

	@time en_K, evec_K, en_Kp, evec_Kp = calc_H_fourier!(arec, kp_band1, para_local1, is_dft, ngvec, gvec, info_gm_sub1, pot_g_sub1, ext_field1, flog)
	print(flog, "calc_H done\n")
	flush(flog)
	plot_band!(kp_band1, is_dft, ngvec, en_K, en_Kp, "cont")
	print(flog, "plot_band done\n")
	flush(flog)

	return en_K, evec_K, en_Kp, evec_Kp
end

input_param = Dict("aM"=>  88.0727310181,
	"is_dft" => true,
    "theta" => 2.14,
    "meff" => 0.368,
    "Eg" => 1.4355,
    "vF" => 0.491983,
    "beta" => [1.62612, 93.6737, -54.265, -2203.28],
	"nk_dft" => 61,
	"nbnd_dft" => 20,
	"kappa" => [[-1/3, -2/3, 0.0], [-2/3, -1/3, 0.0]],
	"band_range" => [-0.06, 0.001],
	"ecut" => 0.1,
	"ngcut" => 5,
	"kp_high" => [[0, 0, 0], [0.5, 0.0, 0.0], [2/3, 1/3, 0], [0, 0, 0]],
	"nksub" => 20,
	"D" => 0.0, 
)

get_band_fourier(input_param)





